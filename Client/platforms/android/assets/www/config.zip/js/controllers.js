angular.module('starter.controllers', ['ngTagsInput'])

	.controller('LoginCtrl', function ($scope, $state, UserService) {
	  
	    $scope.login = function (user) {
	      console.log('Log In', user);

	      UserService.login(user);
		
	  };
	  
	})
	
	.controller('SignupCtrl', function ($scope, $state, UserService) {
	  
	  $scope.continueSignUp = function(user) {
		console.log('Sign up - phase 1', user);
		UserService.fillDetails(user.username, user.password, user.email);
		$state.go('signup2');
	  };
	  
	  $scope.signUp = function(user) {
	      console.log('Sign up - phase 2', user);
	      UserService.fillTags(user.university, user.courses);
	      UserService.register();
		  
	  };
	  
	})

	.controller('HomeTabCtrl', function($scope,$state) {
	    console.log('HomeTabCtrl');
	    //$("#app").draggable();
	    $scope.askquestion = function () {
	        $state.go('askquestion');
	    }
        
	    $scope.hotquestions = function () {
	        $state.go('hotquestions');
	    }
	})
	
	.controller('AskQuestionCtrl', function ($scope, $state, QuestionService, UserService) {
        
		 $scope.takePic = function() {
		     navigator.camera.getPicture(onSuccess, onFail, {
		         quality: 45,
		         //destinationType: Camera.DestinationType.DATA_URL
		         destinationType: Camera.DestinationType.FILE_URI,
		         encodingType: Camera.EncodingType.JPEG,
		         sourceType: Camera.PictureSourceType.CAMERA
		     });

		 }

		 var onSuccess = function (imageUri) {
		     $scope.picData = imageUri;
		     uploadPhoto(imageUri)
	        $scope.$apply();
			
	    };
        
		 function uploadPhoto(imageURI) {
		     var options = new FileUploadOptions();
		     options.fileKey = "file";
		     options.fileName = imageURI.substr(imageURI.lastIndexOf('/') + 1) + '.jpg';
		     options.mimeType = "image/jpeg";

		     var params = new Object();
		     params.test = "test";
		     options.params = params;

		     var ft = new FileTransfer();
		     ft.upload(imageURI, "http://10.10.8.90/AskQuestion", function () { }, onFail, options);
		 }

	    // var onSuccess = function (imageData) {
	    //    $scope.picData = "data:image/jpeg;base64," + imageData;
	    //    $scope.$apply();
	    //};


		var onFail = function(e) {
		    console.log("On fail " + e);
            $scope.errormessage = "Fail: " + e;
		}

		$scope.submit = function()
		{
		    QuestionService.setComment($scope.comment);
		    QuestionService.setTags($scope.tags);
		    QuestionService.askQuestion($scope.picData);
		}

		$scope.tags = [];
        
		$scope.loadTags = function () {
		    return [];//$http.get('tags.json');
		};
	})

    .controller('HotQuestionsCtrl', function ($scope, UserService, QuestionService) {

        $scope.comment = QuestionService.getQuestions(1)[0].comment;

        $scope.tags = QuestionService.getQuestions(1)[0].tags;

        $scope.imagedata = QuestionService.getQuestions(1)[0].imagedata;

        $scope.email = UserService.getUser().email;
    });