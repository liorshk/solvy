'use strict';

/* Filters */

angular.module('starter.filters', []);
